#include <stdio.h>
#include <math.h>

#define PI 3.14159265
#define PLANET_COUNT 8
// 2.1 Serbest Düsme Deneyi
void serbestDusme(float *g_dizi, char *ad) {
    float t, h;
    printf("\n[%s] Serbest dusme suresini (t) saniye cinsinden giriniz: ", ad);
    scanf("%f", &t);
    t = (t < 0) ? -t : t; // Ternary ile mutlak deger

    for (int i = 0; i < PLANET_COUNT; i++) {
        h = 0.5 * (*(g_dizi + i)) * t * t;
        printf("Gezegen %d: Dusme Mesafesi = %.2f m\n", i+1, h);
    }
}
// 2.2. Yukari Atıs Deneyi
void yukariAtis(float *g_dizi, char *ad) {
    float v0, hmax;
    printf("\n[%s] Firlatma hizini (v0) m/s cinsinden giriniz: ", ad);
    scanf("%f", &v0);
    v0 = (v0 < 0) ? -v0 : v0; // Ternary mutlak deger

    for (int i = 0; i < PLANET_COUNT; i++) {
        hmax = (v0 * v0) / (2 * (*(g_dizi + i))); // Pointer ile erisim
        printf("Gezegen %d: Maksimum Yukseklik = %.2f metre\n", i + 1, hmax);
    }
}
// 2.3 Agirlik Deneyi
void agirlikDeneyi(float *g_dizi, char *ad) {
    float m, G;
    printf("\n[%s] Kutleyi (m) kg cinsinden giriniz: ", ad);
    scanf("%f", &m);
    m = (m < 0) ? -m : m;

    for (int i = 0; i < PLANET_COUNT; i++) {
        G = m * (*(g_dizi + i));
        printf("Gezegen %d: Agirlik G = %.2f Newton\n", i+1, G);
    }
}
// 2.4. Kütlecekimsel Potansiyel Enerji Deneyi
void potansiyelEnerji(float *g_dizi, char *ad) {
    float m, h, Ep;
    printf("\n[%s] Kutleyi (m) kg cinsinden giriniz: ", ad);
    scanf("%f", &m);
    printf("\n[%s] Yuksekligi (h) metre cinsinden giriniz: ", ad);
    scanf("%f", &h);
    m = (m < 0) ? -m : m;
    h = (h < 0) ? -h : h;

    for (int i = 0; i < PLANET_COUNT; i++) {
        Ep = m * (*(g_dizi + i)) * h;
        printf("Gezegen %d: Potansiyel Enerji = %.2f Joule\n", i + 1, Ep);
    }
}
// 2.5. Hidrostatik Basinc Deneyi
void hidrostatikBasinc(float *g_dizi, char *ad) {
    float rho, h, P;
    printf("\n[%s] Sivi yogunlugunu (rho) kg/m^3 giriniz: ", ad);
    scanf("%f", &rho);
    printf("\n[%s] Derinligi (h) metre giriniz: ", ad);
    scanf("%f", &h);
    rho = (rho < 0) ? -rho : rho;
    h = (h < 0) ? -h : h;

    for (int i = 0; i < PLANET_COUNT; i++) {
        P = rho * (*(g_dizi + i)) * h;
        printf("Gezegen %d: Hidrostatik Basinc = %.2f Pascal\n", i + 1, P);
    }
}
// 2.6. Arsimet Kaldirma Kuvveti Deneyi
void kaldirmaKuvveti(float *g_dizi, char *ad) {
    float rho, V, Fk;
    printf("\n[%s] Sivi yogunlugunu (rho) kg/m^3 giriniz: ", ad);
    scanf("%f", &rho);
    printf("\n[%s] Batan hacmi (V) m^3 giriniz: ", ad);
    scanf("%f", &V);
    rho = (rho < 0) ? -rho : rho;
    V = (V < 0) ? -V : V;

    for (int i = 0; i < PLANET_COUNT; i++) {
        Fk = rho * (*(g_dizi + i)) * V;
        printf("Gezegen %d: Kaldirma Kuvveti = %.2f Newton\n", i + 1, Fk);
    }
}
// 2.7. Basit Sarkaç Periyodu Deneyi
void basitSarkac(float *g_dizi, char *ad) {
    float L, T;
    printf("\n[%s] Sarkac uzunlugunu (L) metre cinsinden giriniz: ", ad);
    scanf("%f", &L);
    L = (L < 0) ? -L : L;

    for (int i = 0; i < PLANET_COUNT; i++) {
        T = 2 * PI * sqrt(L / (*(g_dizi + i)));
        printf("Gezegen %d: Periyot T = %.2f saniye\n", i + 1, T);
    }
}
// 2.8. Sabit Ip Gerilmesi Deneyi
void ipGerilmesi(float *g_dizi, char *ad) {
    float m, T_gerilme;
    printf("\n[%s] Asili kutleyi (m) kg cinsinden giriniz: ", ad);
    scanf("%f", &m);
    m = (m < 0) ? -m : m;

    for (int i = 0; i < PLANET_COUNT; i++) {
        T_gerilme = m * (*(g_dizi + i));
        printf("Gezegen %d: Ip Gerilmesi T = %.2f Newton\n", i + 1, T_gerilme);
    }
}
// 2.9 Asansor Deneyi
void asansorDeneyi(float *g_dizi, char *ad) {
    float m, a, N;
    int yon;
    printf("\n[%s] Kutleyi (m) kg giriniz: ", ad);
    scanf("%f", &m);
    printf("\n[%s] Asansor ivmesini (a) m/s^2 giriniz: ", ad);
    scanf("%f", &a);
    m = (m < 0) ? -m : m;
    a = (a < 0) ? -a : a;

    printf("Durum: 1-Yukari Hizlanan/Asagi Yavaslayan, 2-Asagi Hizlanan/Yukari Yavaslayan: ");
    scanf("%d", &yon);

    for (int i = 0; i < PLANET_COUNT; i++) {
        float g = *(g_dizi + i);
        if (yon == 1)
            N = m * (g + a);
        else
            N = m * (g - a);
        printf("Gezegen %d: Etkin Agirlik = %.2f N\n", i+1, N);
    }
}

int main() {
    // Gezegen yerçekimi ivmeleri (Merkür, Venüs, Dünya, Mars, Jüpiter, Satürn, Uranüs, Neptün)
    float g_ivmeleri[PLANET_COUNT] = {3.7, 8.87, 9.81, 3.71, 24.79, 10.44, 8.69, 11.15};
    char bilimInsani[50];
    int secim = 0;

    printf("--- UZAY SIMULASYONUNA HOS GELDINIZ ---\n");
    printf("Bilim insaninin adini giriniz: ");
    scanf("%s", bilimInsani);

    while (1) {
        printf("\n--- DENEY MENUSU (Sayin %s) ---\n", bilimInsani);
        printf("1. Serbest Dusme Deneyi\n2. Yukari Atis Deneyi\n3. Agirlik Deneyi\n");
        printf("4. Kutlecekimsel Potansiyel Enerji Deneyi\n5. Hidrostatik Basinc Deneyi\n");
        printf("6. Arsimet Kaldirma Kuvveti Deneyi\n7. Basit Sarkac Periyodu Deneyi\n");
        printf("8. Sabit Ip Gerilmesi Deneyi\n9. Asansor Deneyi\n-1. Cikis\n");
        printf("Seciminiz: ");
        scanf("%d", &secim);

        if (secim == -1) break;

        switch (secim) {
            case 1: serbestDusme(g_ivmeleri, bilimInsani); break;
            case 2: yukariAtis(g_ivmeleri, bilimInsani); break;
            case 3: agirlikDeneyi(g_ivmeleri, bilimInsani); break;
            case 4: potansiyelEnerji(g_ivmeleri, bilimInsani); break;
            case 5: hidrostatikBasinc(g_ivmeleri, bilimInsani); break;
            case 6: kaldirmaKuvveti(g_ivmeleri, bilimInsani); break;
            case 7: basitSarkac(g_ivmeleri, bilimInsani); break;
            case 8: ipGerilmesi(g_ivmeleri, bilimInsani); break;
            case 9: asansorDeneyi(g_ivmeleri, bilimInsani); break;
            default: printf("Gecersiz secim!\n");
        }
    }

    return 0;
}





















